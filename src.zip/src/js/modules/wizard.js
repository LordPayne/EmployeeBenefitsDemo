import 'script-loader!smartwizard/dist/js/jquery.smartWizard.min.js';
