import feather from "feather-icons";

document.addEventListener("DOMContentLoaded", function() {
  feather.replace();
});

window.feather = feather;