import 'bootstrap-daterangepicker/daterangepicker.js'
